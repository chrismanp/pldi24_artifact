#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv) {
  long len = atoi(argv[1]);
  long start = atoi(argv[2]);
  
  long * a = malloc(len*sizeof(long));
  long * b = malloc(len*sizeof(long));
  long * c = malloc(len*sizeof(long));

  for(long i=start; i<len; i++) {
    a[i] = b[i] + c[i];
  }
  
  for(long i=0; i<len; i++) {
    printf("%ld\n", a[i]);
  }

  return 0;
}
