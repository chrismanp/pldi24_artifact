#include <cilk/cilk.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>


int a[100][100];
int b[100][100];
int c[100];


#if 0
int init_B(int n, int m) {
  for(int j=0; j<n; j++) {
    for(int i=0; i<m; i++) {
      b[i][j] = 0;
    }
  }
  return 0;
}

#else
__attribute__((noinline))
int init_A (int n, int m) {
#if 0
  cilk_for(int j=0; j<n; j++) {
    cilk_for(int i=0; i<m; i++) {
      a[i][j] = 0;
    }
  }
#else
  cilk_for(int i=0; i<m; i++) {
    c[i] = 105;
  }
#endif
  return 0;
}

#endif

int main(int argc, char *argv[]) {
  
  int n = atoi(argv[1]);
  int m = atoi(argv[2]);
  
  
#if 0
  init_B(n, m);
#else
  init_A(n, m);
#endif    
}
