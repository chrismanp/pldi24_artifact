#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <pthread.h>
#include <assert.h>
#include <sched.h>
#include <sys/time.h>
#include <time.h>

char flipCoin() {
  int random_value = rand() % 100;
  return random_value < 1; 
}

pthread_barrier_t barrierInit;

unsigned long long __cilkrts_getticks(void)
{
#if defined __i386__ || defined __x86_64
  unsigned a, d;
  __asm__ volatile("rdtsc" : "=a" (a), "=d" (d));
  return ((unsigned long long)a) | (((unsigned long long)d) << 32);
#else
#   warning "unimplemented cycle counter"
  return 0;
#endif
}

#define ss_fence() asm volatile("mfence"::)

int memArr[1000000];

int cntrqst =0;

void stealRequestHandler_sigusr (int signo, siginfo_t *info, void *vcontext) {
  cntrqst++;
  return;
}


void run0() {
  volatile int k = 0;  
  ss_fence();  
  unsigned long long start = __cilkrts_getticks();
  volatile int j = 0;
  for(volatile int i=0; i<100000000; i++) {
    //getpid();
    //k++;
    //ss_fence();
    //if(flipCoin()) {
    //  k++;
    //} else {
    //  k--;
    //}
    memArr[i%1000000]++;
  }
  ss_fence();
  unsigned long long end = __cilkrts_getticks();

  printf("Thread 0 total cycles: %lld cntrqst: %d\n", end-start,  cntrqst);
}

void run1() {
  ss_fence();
  unsigned long long start = __cilkrts_getticks();
  volatile int j = 0;
  for(volatile int i=0; i<1000000; i++) {
    memArr[i%1000000]++;
  }
  ss_fence();
  unsigned long long end = __cilkrts_getticks();

  printf("Thread 1 total cycles: %lld\n", end-start);
}

pthread_t t1id;

void* testthread(void * arg)
{
  int tid = (int)(long long int)arg;
   
  if( tid == 0) {
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    CPU_SET(1, &cpuset);
    pthread_t threaddesc = pthread_self();
    int res = pthread_setaffinity_np(threaddesc, sizeof(cpu_set_t), &cpuset);
    assert(res == 0);

    t1id = pthread_self();

    pthread_barrier_wait(&barrierInit);
    run0();
    
  } else {
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    CPU_SET(29, &cpuset);
    pthread_t threaddesc = pthread_self();
    int res = pthread_setaffinity_np(threaddesc, sizeof(cpu_set_t), &cpuset);
    assert(res == 0);
    
    pthread_barrier_wait(&barrierInit);
    run1();


  }
  return NULL;
}

#define NPROCS 2


int main(void)
{
    printf("./mfence_smt\n");
    pthread_t t[NPROCS];
    
    memset(&memArr[0], 0, sizeof(int)*1000000);

    pthread_barrier_init(&barrierInit, NULL, NPROCS+1);
    for(int i = 0; i<NPROCS; i++) {
      pthread_create(&t[i], NULL, testthread, (void*)(long long int) i);
    }

    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    CPU_SET(0, &cpuset);
    pthread_t threaddesc = pthread_self();
    int res = pthread_setaffinity_np(threaddesc, sizeof(cpu_set_t), &cpuset);
    assert(res == 0);


    pthread_barrier_wait(&barrierInit);
    
    struct sigaction action1;

    action1.sa_flags = SA_SIGINFO | SA_RESTART;
    action1.sa_sigaction = stealRequestHandler_sigusr;
    
    if (sigaction(SIGUSR1, &action1, NULL) == -1) {
      perror("sigusr: sigaction");
      exit(1);
    }

    
    while (1) {
      for(volatile int i =0 ; i<1000; i++) {}
      pthread_kill(t1id, SIGUSR1);
    }
    
    for(int i = 0; i<NPROCS; i++) {
      pthread_join(t[i], NULL);
    }
    printf("Test succeed!\n");
    
    return 0;
}
