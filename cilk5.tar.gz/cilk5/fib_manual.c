/*
 * Copyright (c) 1994-2003 Massachusetts Institute of Technology
 * Copyright (c) 2003 Bradley C. Kuszmaul
 * Copyright (c) 2013 I-Ting Angelina Lee and Tao B. Schardl
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include <cilk/cilk.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>

extern void resume2scheduler_eager(void** ctx, int fromSync);
extern char sync_eagerd(void** ctx, int owner, void* savedRSP, void* currentRSP);
extern void** allocate_parallelctx2(void**ctx);
extern void set_joincntr(void**ctx);
extern void deallocate_parallelctx(void** ctx);

extern __thread int threadId;

#define callerTrashed() asm volatile("# all caller saved are trashed here" : : : "rdi", "rsi", "r8", "r9", "r10", "r11", "rdx", "rcx", "rax")
#define calleeTrashed() asm volatile("# all callee saved are trashed here" : : : "rbx", "r12", "r13", "r14", "r15", "rax")
#define intregTrashed() asm volatile("# all integer saved are trashed here" : : : "rbx", "r12", "r13", "r14", "r15", "rax", "rdi", "rsi", "r8", "r9", "r10", "r11", "rdx", "rcx", "xmm0")


unsigned long long todval (struct timeval *tp) {
    return tp->tv_sec * 1000 * 1000 + tp->tv_usec;
}

__attribute__((noinline))
void startup_cilk() {
  double g = 2.0;
  cilk_for(int i = 0; i<1000; i++) {
    g++;
  }
}

#ifdef SERIAL
#include <cilk/cilk_stub.h>
#endif

#define getSP(sp) asm volatile("#getsp\n\tmovq %%rsp,%[Var]" : [Var] "=r" (sp))

int fib(int n, int depth);

__attribute__((optnone))
__attribute__((noinline))
__attribute__((no_unwind_path))
void fibWrapper(int n, int depth, void** readyCtx, int* x) {
  int bWorkNotPush;
  push_workctx_eager(readyCtx, &bWorkNotPush);
  *x = fib(n, depth);
  pop_workctx_eager(readyCtx, &bWorkNotPush);
  return;
}

__attribute__((noinline))
int fib_lazy(int n) {
  if (n < 2) {
    return (n);
  }
  int x, y;
  x = cilk_spawn 
    fib_lazy(n-1);
  y = fib_lazy(n-2);
  cilk_sync;
  return x+y;
}

__attribute__((noinline))
__attribute__((no_unwind_path))
int fib(int n, int depth) {
  volatile int owner = threadId;
  volatile void* readyCtx[64];  

  if (n < 2) {
    return (n);
  } else if(n < depth) {
    return fib_lazy(n);
  } else {
    int x, y;

    void** ctx = allocate_parallelctx2((void**)readyCtx);
    // Store sp
    getSP(readyCtx[2]);
    readyCtx[23] = NULL;
    readyCtx[21] = NULL;
    readyCtx[24] = (void*) -1;
    readyCtx[19] = (void*)owner;
    readyCtx[20] = (void*)&readyCtx[0];
    //llvm.uli.save.context.nosp();
    int volatile dummy_a= 0;
    asm volatile("movl $0, %[ARG]\n\t":[ARG] "=r" (dummy_a));  
    __builtin_uli_save_context_nosp((void*)readyCtx, &&det_cont);
    if(dummy_a) {
      goto det_cont;
    }
    fibWrapper(n - 1, depth, (void**) &readyCtx[0], &x);
    //x = fib(n - 1, depth);
  det_cont:    
    intregTrashed();
    y = fib(n - 2, depth);
    
    void* sp2;// = (void*)__builtin_read_sp();
    getSP(sp2);
    if(!sync_eagerd((void**)readyCtx, owner, readyCtx[2], sp2)) {
      __builtin_uli_save_context_nosp((void*)readyCtx, &&sync_pre_resume_parent);
      if(dummy_a) {
	goto sync_pre_resume_parent;
      }      
      resume2scheduler_eager((void**)readyCtx, 1);
      
  sync_pre_resume_parent:
      intregTrashed();
      set_joincntr((void**)readyCtx);
    }
    
    deallocate_parallelctx((void**)readyCtx);

    return (x + y);
  }
}

int main(int argc, char *argv[]) {

  // Initailize_lazyd() --> pthread_create(): creates the worker. -> n-1 worker execute simproc, 1 worker execute the remaining code
  int n, result, round, depth;
  round = 1;
  depth = 0;
  if (argc != 4) {
    fprintf(stderr, "Usage: fib_manual [<cilk options>] <n> <lazy n> <number of round>\n");
    exit(1);
  }

  // Start up cilk runtime
  startup_cilk();

  n = atoi(argv[1]);
  depth = atoi(argv[2]);
  round = atoi(argv[3]);

  for(int r=0; r<round; r++) {

    struct timeval t1, t2;
    gettimeofday(&t1,0);
    result = fib(n, depth);

    gettimeofday(&t2,0);
    unsigned long long runtime_ms = (todval(&t2)-todval(&t1))/1000;
    printf("PBBS-time: %f\n", runtime_ms/1000.0);
    fprintf(stderr, "Result: %d\n", result);

  }
  return 0;
}
