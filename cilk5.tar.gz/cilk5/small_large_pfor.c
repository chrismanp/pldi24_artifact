#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <cilk/cilk.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>
#include <assert.h>

//#define I 16000000
//#define J 1000000
#define J 10000
//#define K 256
#define K 16
#define I J*K

#define R 100

unsigned long long todval (struct timeval *tp) {
    return tp->tv_sec * 1000 * 1000 + tp->tv_usec;
}

__attribute__((noinline))
void startup_cilk() {
  double g = 2.0;
  cilk_for(int i = 0; i<1000; i++) {
    g++;
  }
}

int main (int argc, char ** argv) {
  
  struct timeval t1, t2;

  //startup_cilk();

  int *arr = malloc(I*sizeof(int));

  gettimeofday(&t1,0);
  for(int j=0; j<J; j++) {
    #pragma cilk grainsize 9
    cilk_for(int k=0; k<K; k++) {
      // 0 1 2 3 4 5 6 7 8 9
      // 10 11 12 13 14 15 16 17 18 19
      // 20 ....
      //__builtin_uli_unwind_poll();
      for(volatile int r=0;r<R;r++) {       
	//__builtin_uli_unwind_poll();
	arr[K*j+k] = 10;
	//__builtin_uli_unwind_poll();
      }
      //__builtin_uli_unwind_poll();
    }
  }  
  gettimeofday(&t2,0);
  unsigned long long runtime_ms = (todval(&t2)-todval(&t1))/1000;
  printf("PBBS-time: %f\n", runtime_ms/1000.0);
    
  for (int i=0; i<I; i++) {
    assert(arr[i] == 10);
  }

#if 0
  gettimeofday(&t1,0);  
  cilk_for (int i=0; i<I; i++) {
    for(volatile int r=0;r<100;r++)
      arr[i] = 20;

  }
  gettimeofday(&t2,0);
  runtime_ms = (todval(&t2)-todval(&t1))/1000;
  printf("PBBS-time: %f\n", runtime_ms/1000.0);

  for (int i=0; i<I; i++) {
    assert(arr[i] == 20);
  }
#endif
  
  free(arr);

  return 0;
}
