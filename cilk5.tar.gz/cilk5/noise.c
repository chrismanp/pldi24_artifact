#define _GNU_SOURCE
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <sched.h>
#include <assert.h>

void* simproc(void * arg) {

  int threadid = (int)(long long int)arg;
  cpu_set_t cpuset;
  CPU_ZERO(&cpuset);
  CPU_SET(threadid+1, &cpuset);
  pthread_t threaddesc = pthread_self();
  int res = pthread_setaffinity_np(threaddesc, sizeof(cpu_set_t), &cpuset);
  assert(res == 0);

  volatile long i =0;
  while(1) {
    i++;
    if(i > 100000000) {
      
    }
  }
}

int main () {
  
  // Do an infinite loop  
  char * nworkers = getenv("CILK_NWORKERS");
  int nthreads = 0;
  if(nworkers){
    nthreads = atoi(nworkers);
  }  else {
    nthreads =1;
  }

  pthread_t threadids[28];

  for(int i=1; i< nthreads;i++){
    pthread_create(&threadids[i], NULL, simproc, (void*)(long long int)i);
  }

  int threadid = 0;
  cpu_set_t cpuset;
  CPU_ZERO(&cpuset);
  CPU_SET(threadid+1, &cpuset);
  pthread_t threaddesc = pthread_self();
  int res = pthread_setaffinity_np(threaddesc, sizeof(cpu_set_t), &cpuset);
  

  volatile long j=0;
  while(1){
    j++;
    if(j>100000000) {
      
    }
  }

  for(int i =1; i<nthreads;i++){
    pthread_join(threadids[i], NULL);
  }

  return 0;
}
