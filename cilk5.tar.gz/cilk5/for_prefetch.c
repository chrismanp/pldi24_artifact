
#include "stdio.h"

int main(int argc, char ** argv) {


  int N = atoi(argv[1]);
  int *a = malloc(sizeof(int)*1000000);
  for(int i=0; i<N; i++) {
    __builtin_prefetch(a+1);
    a[i] = 0;
  }
  free(a);  
}
